#include <time.h>
#include <stdio.h>

#include "x264/h264encwrapper.h"
#include "camera/icameracaptuer.h"

#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "Debug/libH264Encoder.lib")
#pragma comment(lib, "Debug/libCameraCaptuer.lib")

#define VIDEO_WIDTH   640
#define VIDEO_HEIGHT  480

#include "vshmvideo.h"

#ifdef WIN32
inline int32_t gettimeofday(struct timeval *tp, void *tzp)
{
  time_t clock;
  struct tm tm;
  SYSTEMTIME wtm;

  GetLocalTime(&wtm);
  tm.tm_year = wtm.wYear - 1900;
  tm.tm_mon = wtm.wMonth - 1;
  tm.tm_mday = wtm.wDay;
  tm.tm_hour = wtm.wHour;
  tm.tm_min = wtm.wMinute;
  tm.tm_sec = wtm.wSecond;
  tm.tm_isdst = -1;
  clock = mktime(&tm);
  tp->tv_sec = (long)clock;
  tp->tv_usec = wtm.wMilliseconds * 1000;
  return (0);
}
#endif

int main() {
#ifdef WIN32
  WSADATA wsaData;
  WSAStartup(MAKEWORD(2, 2), &wsaData);
  srand((unsigned int)time(NULL));
#else
  srand((unsigned int)time(NULL));
  srandom((unsigned int)time(NULL));
#endif

  ICameraCaptuer* p_cam = NULL;
  H264EncWrapper* p_h264_enc = NULL;

  p_cam = CamCaptuerMgr::GetCamCaptuer();
  if (p_cam == NULL) {
    printf("can't get camera.\n");
    return -1;
  }

  // ��Camera
  if(!p_cam->OpenCamera(0, 640, 480)) {
    printf("Can not open camera");
    return NULL;
  }

  // ��ʼ��H264 Encode
  p_h264_enc = new H264EncWrapper;
  if(p_h264_enc->Initialize(VIDEO_WIDTH, VIDEO_HEIGHT, 96, 25) < 0) {
    printf("Initialize x264 encoder error");
    return NULL;
  }

  VShmVideo v_shm_vdo;
  int n_ret = v_shm_vdo.Open((int8_t*)("video_0"), sizeof(TAG_SHM_VIDEO));
  if (n_ret != 0) {
    printf("shm video failed.%d.\n", n_ret);
    return n_ret;
  }

  int   n_nal = 0;
  TNAL* p_nal = NULL;
  char* p_data = new char[1024*1024];
  //FILE* file = fopen("./test.h264", "wb+");

  struct timeval tm_now;
  while (p_data) {
    // ���NAL Unit����
    p_h264_enc->CleanNAL(p_nal, n_nal);

    // ��ȡ������Ƶ֡,YUV
    unsigned char *p_img = p_cam->QueryFrame();
    if (p_img) {
      // H264 Encode
      p_h264_enc->Encode(p_img, p_nal, n_nal, false);
      //printf("result %d, 0x%x, nal number %d.\n", n_ret, p_nal, n_nal);
      /*if (file && p_nal) {
        for (int j = 0; j < n_nal; j++) {
        fwrite(p_nal[j].data, 1, p_nal[j].size, file);
        }
        }*/

      if (p_nal) {
        int n_data = 0;
        for (int j = 0; j < n_nal; j++) {
          memcpy(p_data+n_data, p_nal[j].data, p_nal[j].size);
          n_data += p_nal[j].size;
        }

        gettimeofday(&tm_now, NULL);
        n_ret = v_shm_vdo.Write((int8_t*)p_data, n_data, &tm_now);
      }
    }
  }
  return 0;
}
